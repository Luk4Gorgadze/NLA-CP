## 1.1.  Blending digital images (1 point)
* (a)  Take two digital images - ✅ 
* (b)  Blend images for different values of parameters - ✅ 
* (c)  You can use OpenCv library for creating video from set of blendedimages - ✅ 
* (d)  Using arithmetic operations on matrices only is allowed for cre-ating blended images. - ✅ 
* (e)  Test:  your code should work properly on digital images providedby TA.

### Conclusion:
I take two images and blend them only at their intersection area. Images with same dimensions are preferred but anyways, you'll still get nice results 😆😆😆 I included pictures on which i tested my program.