## 1.3.  Ranking students for fellowship applications (2 points)
* (a)  Students  transcript  is  available  for  4  semesters.    In  the  fifthsemester those who do not receive funding, can apply for schol-arship.
* (b)  Students transcripts are given as 4x5 matrix where each linecorrespond to grades for one semester.
* (c)  Which  matrix  norm  is  best  for  ranking  the  students  ?   explain your approach and justify your choice;
* (d)  Generate some data, test your approach and demonstrate
* (e)  Test:  your code should work properly on data provided by TA.

### Conclusion:

* a) I generate synthetic Data for that
* b) Done
* c) Frobenius norm is the best in my poinion, I use this norm on students' marks and rank them accordingly
* d) Generated, Tested
* e) You can replace synthetic data with real one, no prob.